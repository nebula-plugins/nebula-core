Testing the contents of a zip
